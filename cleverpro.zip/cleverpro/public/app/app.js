(function(){
	'use strict';

	angular
		.module('app', [
			'app.config',
			'app.cleverpro',
			'app.services',
			'ngCookies',
		]);
})();
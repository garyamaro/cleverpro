(function(){
	'use strict';

	angular
		.module('app.services')
		.factory('UserSession', UserSession);

	UserSession.$inject = ['$cookies'];

	function UserSession($cookies){
		var service = {
			setUser: setUser,
			getUser: getUser,
			clearUser: clearUser
		};

		return service;

		//////////

		function setUser(user){
			$cookies.putObject('user', user);
		}

		function getUser(){
			return $cookies.getObject('user');
		}

		function clearUser(){
			$cookies.remove('user');
		}
	}
})();
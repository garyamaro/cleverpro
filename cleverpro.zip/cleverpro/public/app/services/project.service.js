(function(){
	'use strict';

	angular
		.module('app.services')
		.factory('ProjectService', ProjectService);

	ProjectService.$inject = ['$http'];

	function ProjectService($http){
		var service = {
			getAll: getAll,
			getById: getById,
			getByCompany: getByCompany,
			getByUser: getByUser
		};

		return service;

		//////////

		function getAll(){
			return $http.get('api/v1/projects').then(handleSuccess, handleError('Error getting all projects'));
		}

		function getById(id){
			return $http.get('api/v1/projects/' + id).then(handleSuccess, handleError('Error getting project by id'));
		}

		function getByCompany(id){
			return $http.get('api/v1/companies/' + id + '/projects').then(handleSuccess, handleError('Error getting project by company id'));
		}

		function getByUser(id){
			return $http.get('api/v1/users/' + id + '/projects').then(handleSuccess, handleError('Error getting projects by user id'));
		}		



		///////////

		function handleSuccess(res){
			return res.data;
		}

		function handleError(error){
			return function(){
				return {success: false, message: error};
			};
		}
	}
})();
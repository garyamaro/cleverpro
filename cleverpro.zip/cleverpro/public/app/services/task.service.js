(function(){
	'use strict';

	angular
		.module('app.services')
		.factory('TaskService', TaskService);

	TaskService.$inject = ['$http'];

	function TaskService($http){
		var service = {
			getAll: getAll,
			getById: getById,
			getByModule: getByModule,
			getByUser: getByUser
		};

		return service;

		//////////

		function getAll(){
			return $http.get('api/v1/tasks').then(handleSuccess, handleError('Error getting all tasks'));
		}

		function getById(id){
			return $http.get('api/v1/tasks/' + id).then(handleSuccess, handleError('Error getting tasks by id'));
		}

		function getByModule(id){
			return $http.get('api/v1/modules/' + id + '/tasks').then(handleSuccess, handleError('Error getting tasks by module id'));
		}

		function getByUser(id){
			return $http.get('api/v1/users/' + id + '/tasks').then(handleSuccess, handleError('Error getting tasks by user id'));
		}

		///////////

		function handleSuccess(res){
			return res.data;
		}

		function handleError(error){
			return function(){
				return {success: false, message: error};
			};
		}
	}
})();
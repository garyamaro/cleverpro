(function(){
	'use strict';

	angular
		.module('app.services')
		.factory('UserService', UserService);

	UserService.$inject = ['$http'];

	function UserService($http){
		var service = {
			getAll: getAll,
			getById: getById,
			getByCompany: getByCompany,
			getByProject: getByProject,
			getUserTypes: getUserTypes,
			addUser: addUser
		};

		return service;

		//////////

		function getAll(){
			return $http.get('api/v1/users').then(handleSuccess, handleError('Error getting all users'));
		}

		function getById(id){
			return $http.get('api/v1/users/' + id).then(handleSuccess, handleError('Error getting user by id'));
		}

		function getByCompany(id){
			return $http.get('api/v1/companies/' + id + '/users').then(handleSuccess, handleError('Error getting user by company id'));
		}

		function getByProject(id){
			return $http.get('api/v1/projects/' + id + '/users').then(handleSuccess, handleError('Error getting users by project id'));
		}

		function getUserTypes(){
			return $http.get('api/v1/user_types').then(handleSuccess, handleError('Error getting user types'));
		}		

		function addUser(user){
			return $http.post('api/v1/users', user).then(handleSuccess, handleError('Error adding user'));
		}


		///////////

		function handleSuccess(res){
			return res.data;
		}

		function handleError(error){
			return function(){
				return {success: false, message: error};
			};
		}
	}
})();
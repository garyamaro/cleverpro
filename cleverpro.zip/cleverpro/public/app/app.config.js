(function(){
	'use strict';

	angular
		.module('app.config', ['ui.router'])
		.config(config);

	config.$inject = ['$stateProvider', '$urlRouterProvider'];

	function config($stateProvider, $urlRouterProvider){
		var URL = {
			TEMPLATES: './app/templates/',
			COMPONENTS: './app/templates/components/',
			CLEVERPRO: './app/cleverpro/'
		};

		$urlRouterProvider.otherwise('/auth');

		$stateProvider
			.state('home', {
				url: '/auth',
				views: {
					'': {templateUrl: URL.TEMPLATES + 'auth.html'},
					'@home': {templateUrl: URL.COMPONENTS + 'wallpaper.html'},
					'sidenav@home' : {templateUrl: URL.COMPONENTS + 'sidenav.html', controller: 'SidenavController', controllerAs: 'vm'}
				}
			})
			.state('home.signup', {
				url: '/signup',
				templateUrl: URL.CLEVERPRO + 'auth/signup.html',
				controller: 'SignupController',
				controllerAs: 'vm'
			})
			.state('home.login', {
				url: '/login',
				templateUrl: URL.CLEVERPRO + 'auth/login.html',
				controller: 'LoginController',
				controllerAs: 'vm'
			})
			.state('welcome', {
				url: '/',
				views: {
					'': {templateUrl: URL.TEMPLATES + 'user.html'},
					'@welcome': {templateUrl: URL.COMPONENTS + 'wallpaper.html'},
					'sidenav@welcome': {templateUrl: URL.COMPONENTS + 'sidenav.html', controller: 'SidenavController', controllerAs: 'vm'}
				}
			})
			.state('welcome.users', {
				url: 'users',
				templateUrl: URL.CLEVERPRO + 'users/home.html',
				controller: 'UserController',
				controllerAs: 'vm'
			})
			.state('welcome.users-add', {
				url: 'users/add',
				templateUrl: URL.CLEVERPRO + 'users/add.html',
				controller: 'UserAddController',
				controllerAs: 'vm'
			})
			.state('welcome.projects', {
				url: 'projects',
				templateUrl: URL.CLEVERPRO + 'projects/home.html',
				controller: 'ProjectController',
				controllerAs: 'vm'
			})
			.state('welcome.projects_members', {
				url: 'projects/:projectId/members',
				templateUrl: URL.CLEVERPRO + 'project_members/home.html',
				controller: 'ProjectMemberController',
				controllerAs: 'vm'
			})
			.state('welcome.users-projects', {
				url: 'users/:userId/projects',
				templateUrl: URL.CLEVERPRO + 'projects/home.html',
				controller: 'ProjectController',
				controllerAs: 'vm'
			})
			.state('welcome.modules', {
				url: 'projects/:projectId/modules',
				templateUrl: URL.CLEVERPRO + 'modules/home.html',
				controller: 'ModuleController',
				controllerAs: 'vm'
			})
			.state('welcome.tasks', {
				url: 'modules/:moduleId/tasks',
				templateUrl: URL.CLEVERPRO + 'tasks/home.html',
				controller: 'TaskController',
				controllerAs: 'vm'
			})
			.state('welcome.issues', {
				url: 'projects/:projectId/issues',
				templateUrl: URL.CLEVERPRO + 'issues/home.html',
				controller: 'IssueController',
				controllerAs: 'vm'
			})
			.state('welcome.mytasks', {
				url: 'mytasks',
				templateUrl: URL.CLEVERPRO + 'tasks/home.html',
				controller: 'TaskController',
				controllerAs: 'vm'
			})
			.state('welcome.myissues', {
				url: 'myissues',
				templateUrl: URL.CLEVERPRO + 'issues/home.html',
				controller: 'IssueController',
				controllerAs: 'vm'
			})
			.state('welcome.aboutthecompany', {
				url: 'aboutthecompany',
				templateUrl: URL.CLEVERPRO + 'companies/view.html'
			});
	}
})();
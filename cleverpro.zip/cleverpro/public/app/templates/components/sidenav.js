(function(){
	'use strict';

	angular
		.module('app')
		.controller('SidenavController', SidenavController);

	SidenavController.$inject = ['UserSession', '$state'];

	function SidenavController(UserSession, $state){
		var vm = this;

		vm.logout = logout;
		vm.isUserLoggedin = isUserLoggedin;

		activate();

		function activate(){
			if(UserSession.getUser()){
				
				if(UserSession.getUser()){
					vm.user = UserSession.getUser();
				}else{
					$state.go('home');
				}
			}
		}

		//////////

		function logout(){
			UserSession.clearUser();
		}

		function isUserLoggedin() {
			if(vm.user){
				return true;
			}else{
				return false;
			}
		}
	}

})();
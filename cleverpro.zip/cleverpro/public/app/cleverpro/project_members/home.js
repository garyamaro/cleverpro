(function(){
	'use strict';

	angular
		.module('app.cleverpro')
		.controller('ProjectMemberController', ProjectMemberController);

	ProjectMemberController.$inject = ['UserService', 'UserSession', 'ProjectService', '$stateParams', '$state'];

	function ProjectMemberController(UserService, UserSession, ProjectService, $stateParams, $state){
		var vm = this;

		vm.user = {};
		vm.projectId = $stateParams.projectId;
		vm.users = [];
		vm.project = {};
		activate();

		function activate(){
			if(UserSession.getUser()){
				vm.user = UserSession.getUser();
				
				ProjectService.getById(vm.projectId).then(function(data){
					if(data.project){
						vm.project = data.project;
					}else{
						alert('No Project with id ' + vm.projectId);
						$state.go('welcome.projects');
					}
					
				});
				
				getUsersByCompany();
			}
		}

		//////////

		function getUsersByCompany(){
			UserService.getByProject(vm.projectId).then(function(data){
				vm.users = data.project_users;
			});
		}
	}

})();
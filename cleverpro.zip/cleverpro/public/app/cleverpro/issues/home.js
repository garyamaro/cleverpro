(function(){
	'use strict';

	angular
		.module('app.cleverpro')
		.controller('IssueController', IssueController);

	IssueController.$inject = ['IssueService', 'UserSession', 'ProjectService', '$stateParams', '$state'];

	function IssueController(IssueService, UserSession, ProjectService, $stateParams, $state){
		var vm = this;

		vm.user = {};
		vm.issues = [];
		vm.project = {};
		activate();

		function activate(){
			if(UserSession.getUser()){
				vm.user = UserSession.getUser();
				if($stateParams.projectId){
					vm.projectId = $stateParams.projectId;
					ProjectService.getById(vm.projectId).then(function(data){
						if(data.project){
							vm.project = data.project;
						}else{
							alert('No Project with id ' + vm.projectId);
							$state.go('welcome.projects');
						}
						
					});
					getIssuesByProject(vm.projectId);
				}else{
					getIssuesByUser(vm.user.id);
				}
				
				
				
			}
		}

		//////////

		function getIssuesByProject(id){
			IssueService.getByProject(id).then(function(data){
				vm.issues = data.issues;
			});
		}

		function getIssuesByUser(id){
			IssueService.getByUser(id).then(function(data){
				vm.issues = data.issues;
			});
		}
	}

})();
(function(){
	'use strict';

	angular
		.module('app.cleverpro')
		.controller('ProjectController', ProjectController);

	ProjectController.$inject = ['ProjectService', 'UserSession', '$stateParams'];

	function ProjectController(ProjectService, UserSession, $stateParams){
		var vm = this;

		vm.user = {};
		vm.projects = [];
		vm.project_color = project_color;

		activate();

		function activate(){
			if(UserSession.getUser()){
				vm.user = UserSession.getUser();

				if($stateParams.userId){
					getProjectsByUser($stateParams.userId);
				}else{
					getProjectsByUser(vm.user.id);
				}
				
			}
		}

		//////////

		function getProjectsByUser(id){
			ProjectService.getByUser(id).then(function(data){
				vm.projects = data.projects;
			});
		}

		function project_color(status) {
			if(status == 'not started'){
				return 'w3-pale-red';
			}else if(status == 'in progress'){
				return 'w3-pale-blue';
			}else{
				return 'w3-pale-green';
			}
		}
	}

})();
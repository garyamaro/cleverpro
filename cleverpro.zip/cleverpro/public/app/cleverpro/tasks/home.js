(function(){
	'use strict';

	angular
		.module('app.cleverpro')
		.controller('TaskController', TaskController);

	TaskController.$inject = ['TaskService', 'UserSession', 'ModuleService', '$stateParams', '$state'];

	function TaskController(TaskService, UserSession, ModuleService, $stateParams, $state){
		var vm = this;

		vm.user = {};
		vm.tasks = [];
		vm.module = {};
		activate();

		function activate(){
			if(UserSession.getUser()){
				vm.user = UserSession.getUser();
				
				if($stateParams.moduleId){
					vm.moduleId = $stateParams.moduleId;
					ModuleService.getById(vm.moduleId).then(function(data){
						if(data.module){
							vm.module = data.module;
						}else{
							alert('No module with id ' + vm.module);
							$state.go('welcome.projects');
						}
					});
					getTasksByModule(vm.moduleId);
				}else{
					getTasksByUser(vm.user.id);
				}
				
				
				
			}
		}

		//////////

		function getTasksByModule(id){
			TaskService.getByModule(id).then(function(data){
				vm.tasks = data.tasks;
			});
		}

		function getTasksByUser(id){
			TaskService.getByUser(id).then(function(data){
				vm.tasks = data.tasks;
			});
		}
	}

})();
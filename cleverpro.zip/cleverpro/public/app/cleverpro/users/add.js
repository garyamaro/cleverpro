(function(){
	'use strict';

	angular
		.module('app.cleverpro')
		.controller('UserAddController', UserAddController);

	UserAddController.$inject = ['UserService', 'UserSession'];

	function UserAddController(UserService, UserSession){
		var vm = this;

		vm.user = {};
		vm.users = [];
		vm.addUser = addUser;
		vm.new_user = {
			first_name: '',
			last_name: '',
			email: '',
			password: '',
			user_type_id: 0,
			company_id: 0

		};

		vm.user_types = [];
		
		activate();

		function activate(){
			if(UserSession.getUser()){
				vm.user = UserSession.getUser();
				getUsersByCompany();
				getUserTypes();
			}
		}

		//////////

		function getUsersByCompany(){
			UserService.getByCompany(vm.user.company_id).then(function(data){
				vm.users = data.users;
			});
		}

		function getUserTypes(){
			UserService.getUserTypes().then(function(data){
				if(vm.user.user_type_id == 2){
					vm.user_types = data.user_types;
				}
			});
		}

		function addUser(){
			vm.new_user.company_id = vm.user.company_id;
			UserService.addUser(vm.new_user).then(function(data){
				alert('added successfully');
				console.log(data);
			});
		}
	}

})();
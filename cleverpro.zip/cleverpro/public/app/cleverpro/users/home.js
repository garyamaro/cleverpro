(function(){
	'use strict';

	angular
		.module('app.cleverpro')
		.controller('UserController', UserController);

	UserController.$inject = ['UserService', 'UserSession'];

	function UserController(UserService, UserSession){
		var vm = this;

		vm.user = {};
		vm.users = [];

		activate();

		function activate(){
			if(UserSession.getUser()){
				vm.user = UserSession.getUser();
				getUsersByCompany();
			}
		}

		//////////

		function getUsersByCompany(){
			UserService.getByCompany(vm.user.company_id).then(function(data){
				vm.users = data.users;
			});
		}
	}

})();
(function(){
	'use strict';

	angular
		.module('app.cleverpro')
		.controller('SignupController', SignupController);

	SignupController.$inject = [];

	function SignupController(){
		var vm = this;

		vm.name = 'Gary';
	}
})();
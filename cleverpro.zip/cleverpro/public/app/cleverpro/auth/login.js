(function(){
	'use strict';

	angular
		.module('app.cleverpro')
		.controller('LoginController', LoginController);

	LoginController.$inject = ['UserService', 'UserSession', '$state'];

	function LoginController(UserService, UserSession, $state){
		var vm = this;

		vm.login = login;

		vm.user = {
			email: '',
			password: ''
		};

		activate();

		function activate(){
			
		}

		//////////

		function login(){
			UserService.getById(vm.user.email).then(function(data){
				UserSession.setUser(data.user);
				$state.go('welcome');
			});
			
		}
	}

})();
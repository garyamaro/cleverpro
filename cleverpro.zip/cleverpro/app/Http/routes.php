<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('index');
});

Route::auth();

Route::get('/home', 'HomeController@index');

Route::group(['prefix' => 'api/v1'], function(){

	Route::get('companies/{companyId?}', 'CompanyController@get');
	Route::get('companies/{companyId?}/users', 'CompanyController@users');
	Route::get('companies/{companyId?}/projects', 'CompanyController@projects');

	Route::get('users/{userId?}', 'UserController@get');
	Route::get('users/{userId}/projects', 'UserController@projects');
	Route::get('users/{userId}/tasks', 'UserController@tasks');
	Route::get('users/{userId}/issues', 'UserController@issues');

	Route::post('users', 'UserController@new');

	Route::get('projects/{projectId?}', 'ProjectController@get');
	Route::get('projects/{projectId}/users', 'ProjectController@users');
	Route::get('projects/{projectId}/modules', 'ProjectController@modules');
	Route::get('projects/{projectId}/issues', 'ProjectController@issues');

	Route::get('modules/{moduleId?}', 'ModuleController@get');
	Route::get('modules/{moduleId}/tasks', 'ModuleController@tasks');

	Route::get('tasks/{taskId?}', 'TaskController@get');

	Route::get('issues/{issueId?}', 'IssueController@get');

	Route::get('user_types', 'UserTypeController@getAll');

	Route::post('login', 'LoginController@login');
	Route::post('register', 'RegisterController@register');
});

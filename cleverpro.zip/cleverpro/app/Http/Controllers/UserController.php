<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\User;
use App\Models\Company;
use App\Models\ProjectMember;
use App\Models\Task;
use App\Models\Issue;

class UserController extends Controller
{
    public function getByCompany($companyId = 0){
    	if($companyId == 0){
    		return response()->json([
				'error' => 'company id missing'
			],400);	
    	}

   		return response()->json([
			'users' => Company::find($companyId)->users
		],200);	
    }

    public function get($userId = 0){
    	if($userId == 0){
			return response()->json([
				'users' => User::all()
			],200);	
    	}
    	
    	return response()->json([
			'user' => User::find($userId)
		],200);
    }

    public function projects($userId){
    	return response()->json([
			'projects' => User::find($userId)->projects
		],200);
    }

    public function tasks($userId){
        return response()->json([
            'tasks' => Task::where('developer_id', $userId)
                            ->orWhere('tester_id', $userId)
                            ->get()
        ],200);
    }

    public function issues($userId){
        return response()->json([
            'issues' => Issue::where('developer_id', $userId)->get()
        ],200);
    }

    public function new(Request $request){

        $user = new User;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->password = $request->password;
        $user->company_id = $request->company_id;
        $user->user_type_id = $request->user_type_id;
        $user->save();

        return response()->json([
            'success' => $user
        ],200);
    }
}

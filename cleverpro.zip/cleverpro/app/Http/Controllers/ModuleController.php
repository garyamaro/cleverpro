<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Module;

class ModuleController extends Controller
{
    public function get($moduleId = 0){
    	if($moduleId == 0){
			return response()->json([
				'modules' => Module::all()
			], 200);
		}

		return response()->json([
			'module' => Module::find($moduleId)
		], 200);
    }

    public function tasks($moduleId){
    	return response()->json([
			'tasks' => Module::find($moduleId)->tasks
		], 200);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Company;

class CompanyController extends Controller
{	
    public function get($companyId = 0){
    	if($companyId == 0){
			return response()->json([
				'companies' => Company::all()
			],200);	
    	}
    	return response()->json([
			'company' => Company::find($companyId)
		],200);
    	
    }

    public function users($companyId){
    	return response()->json([
			'users' => Company::find($companyId)->users
		],200);
    }

    public function projects($companyId){
    	return response()->json([
			'projects' => Company::find($companyId)->projects
		],200);
    }

}

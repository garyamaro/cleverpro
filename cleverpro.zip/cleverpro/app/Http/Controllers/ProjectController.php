<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Project;
use App\Models\ProjectMember;
use App\Models\Company;
use App\Models\User;
use App\Models\Module;

class ProjectController extends Controller
{
	public function get($projectId = 0){
		if($projectId == 0){
			return response()->json([
				'projects' => Project::all()
			], 200);
		}

		return response()->json([
			'project' => Project::find($projectId)
		], 200);
	}

    public function users($companyId){
    	return response()->json([
			'project_users' => Project::find($companyId)->users
		],200);
    }

    public function modules($companyId){
    	return response()->json([
			'modules' => Project::find($companyId)->modules
		],200);
    }

    public function issues($companyId){
    	return response()->json([
			'issues' => Project::find($companyId)->issues
		],200);
    }

}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\User;

class LoginController extends Controller
{
    public function login($data){
    	return response()->json([
			'user' => User::find(1)
		],200);
    }
}

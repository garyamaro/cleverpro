<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Models\Task;

class TaskController extends Controller
{
    public function get($taskId = 0){
    	if($taskId == 0){
			return response()->json([
				'tasks' => Task::all()
			], 200);
		}

		return response()->json([
			'task' => Task::find($taskId)
		], 200);
    }
}

<!DOCTYPE html>
<html data-ng-app="app" ng-strict-di>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>CLEVERPRO</title>
    <style>
    body {font-family: "Times New Roman", Georgia, Serif;}
    h1,h2,h3,h4,h5,h6 {
        font-family: "Playfair Display";
        letter-spacing: 5px;
    }
    </style>
	<!-- <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css"> -->
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!-- Latest compiled and minified JavaScript
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
 -->
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/w3.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/app.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/css/animate.css') }}">
	<!-- Bootstrap Core CSS -->
	<!-- <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/bootstrap.min.css') }}"> -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/bootstrap.css') }}">

    <!-- MetisMenu CSS -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/metisMenu.min.css') }}">

    <!-- Custom CSS -->
   <!--  <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/sb-admin-2.css') }}"> -->

    <!-- Morris Charts CSS -->
     <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/morris.css') }}">

    <!-- Custom Fonts -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/font-awesome.min.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/font-awesome.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/app.css') }}">

</head>
<body>

	<div ui-view></div>

    <script src="{{ asset('assets/js/charts/loader.js') }}"></script>


    <script src="{{ asset('assets/js/jquery.min.js') }}"></script>
    
    <!-- Bootstrap Core JavaScript -->
    <script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
    <!-- Metis Menu Plugin JavaScript -->
    <script src="{{ asset('assets/js/metisMenu.min.js') }}"></script>
    <!-- Morris Charts JavaScript -->
    <script src="{{ asset('assets/js/raphael.min.js') }}"></script>
    <script src="{{ asset('assets/js/morris.min.js') }}"></script>
    <script src="{{ asset('assets/js/morris-data.js') }}"></script>
    <!-- Custom Theme JavaScript -->
    <script src="{{ asset('assets/js/sb-admin-2.min.js') }}"></script>  

	<script src="{{ asset('assets/js/angular.min.js') }}"></script>
    <script src="{{ asset('assets/js/angular-ui-router.js') }}"></script>
	<script src="{{ asset('assets/js/angular-cookies.js') }}"></script>

        
    <!-- CleverPro Scripts-->    
    <script src="{{ asset('app/app.js') }}"></script>
    <script src="{{ asset('app/app.config.js') }}"></script>

    <script src="{{ asset('app/services/services.js') }}"></script>
    <script src="{{ asset('app/services/user.service.js') }}"></script>
    <script src="{{ asset('app/services/project.service.js') }}"></script>
    <script src="{{ asset('app/services/module.service.js') }}"></script>
    <script src="{{ asset('app/services/task.service.js') }}"></script>
    <script src="{{ asset('app/services/issue.service.js') }}"></script>
    <script src="{{ asset('app/services/auth.service.js') }}"></script>
    <script src="{{ asset('app/services/user.session.js') }}"></script>

    <script src="{{ asset('app/templates/components/topnav.js') }}"></script>
    <script src="{{ asset('app/templates/components/sidenav.js') }}"></script>

    <script src="{{ asset('app/cleverpro/cleverpro.js') }}"></script>

    <script src="{{ asset('app/cleverpro/auth/signup.js') }}"></script>
    <script src="{{ asset('app/cleverpro/auth/login.js') }}"></script>

    <script src="{{ asset('app/cleverpro/users/home.js') }}"></script>
    <script src="{{ asset('app/cleverpro/users/add.js') }}"></script>

    <script src="{{ asset('app/cleverpro/projects/home.js') }}"></script>

    <script src="{{ asset('app/cleverpro/project_members/home.js') }}"></script>

    <script src="{{ asset('app/cleverpro/modules/home.js') }}"></script>

    <script src="{{ asset('app/cleverpro/tasks/home.js') }}"></script>

    <script src="{{ asset('app/cleverpro/issues/home.js') }}"></script>

</body>
</html>